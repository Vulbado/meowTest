#!/bin/sh
./fwupdate.sh 's53_fw_swv5.0.10.13_dsp_test_release.hex' 's53_ubl_swv5.0.10.13_release.hex' '0x04E28DC7' '0x80974162'
